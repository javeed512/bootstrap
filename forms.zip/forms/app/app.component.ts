import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'myapp';

    mycolor:string ="blue";

    name:string ="javeed";

    city:string ="newyork";

    url:string ="/assets/python.png";


    onSubmit():void{


        alert("This is Click Event");

    }



    




    


}
