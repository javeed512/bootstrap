export class Customer {
    id: number = 0;
    name: string = "";
    age: number =0;
    active: boolean = false;
}
