import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-empdisplay',
  templateUrl: './empdisplay.component.html',
  styleUrls: ['./empdisplay.component.css'],
  providers:[EmployeeService]
})
export class EmpdisplayComponent implements OnInit {

    
    empList:Employee[] =[];

  constructor(private  _service:EmployeeService) { }

  ngOnInit(): void {

    this.getAllEmployee();
  }

    getAllEmployee(){

      this._service.getAllEmployees().subscribe(data => this.empList = data);


    }

    delete(i:number){

      this.empList.splice(i,1);

    }


    addEmployee(data:any){

        console.log(data.value)

        this.empList.push(data.value);


    }





}








