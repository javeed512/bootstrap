import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  constructor() { }


  getBalance(){

      console.log("Your balance is 7000");


  }



}
