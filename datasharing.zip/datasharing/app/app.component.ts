import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'datasharing';

    parentInput:string = "Hi I am Parent";


    getData(value:any){

        console.log(value);


    }


}
