import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

    @Input()
    myInput:string="";

   @Output()
    myOutput:EventEmitter<string> = new EventEmitter();

      childData:string ="Hi I am YOur Child";

    sendDataToParent(){

        this.myOutput.emit(this.childData);

    }
          








  constructor() {

    console.log(this.myInput);



  }

  ngOnInit(): void {
    console.log(this.myInput);



  }

}
