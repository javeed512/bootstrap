package com.javasampleapproach.springrest.postgresql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestPostgreSqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestPostgreSqlApplication.class, args);
	}
}
