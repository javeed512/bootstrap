
export interface Employee{

    id:number;
    ename:string;
    salary:number;


}
